//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

int count = 0;

struct Tree
{
        int info;
        Tree *left, *right;
} *root;

Tree* List(int info)
{
        Tree *t = new Tree;
        t -> info = info;
        t -> left = t -> right = NULL;
        return t;
}

void AddList(Tree *root, int info)
{
        if (info > root -> info)
        {
                if (root -> right == NULL) root -> right = List(info);
                else AddList(root -> right, info);
        }
        else if (info < root -> info)
        {
                if (root -> left == NULL) root -> left = List(info);
                else AddList(root -> left, info);
        }
        else ShowMessage("������� ��� ����������!");
}

void PrintTree(Tree *root, int prev)
{
        Form1->Memo1->Lines->Add((AnsiString)"(" + prev + (AnsiString)") " + root->info);
        if(root->left != NULL) PrintTree(root->left, root->info);
        if(root->right != NULL) PrintTree(root->right, root->info);
}

void Find(Tree *root, int info)
{
        if (info > root -> info)
        {
                if (root -> right == NULL) ShowMessage("�������� �� �������");
                else Find(root -> right, info);
        }
        else if (info < root -> info)
        {
                if (root -> left == NULL) ShowMessage("�������� �� �������");
                else Find(root -> left, info);
        }
        else ShowMessage("�������� �������");
}

Tree* Minimum(Tree *root)
{
        if (root->left == NULL) return root;
        return Minimum(root->left);
}

Tree* Delete(Tree *root, int info)
{
        if (root == NULL) return root;
        if (info < root->info) root->left = Delete(root->left, info);
        else if (info > root->info) root->right = Delete(root->right, info);
        else if (root->left != NULL && root->right != NULL)
        {
                root->info = Minimum(root->right)->info;
                root->right = Delete(root->right, root->info);
        }
        else
        {
                if (root->left != NULL) root = root->left;
                else root = root->right;
        }
        return root;
}

void Calc(Tree *root)
{
        if(root->left == NULL && root->right == NULL) count++;
        if(root->left != NULL) Calc(root->left);
        if(root->right != NULL) Calc(root->right);

}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
        root = List(StrToInt(Edit1->Text));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button5Click(TObject *Sender)
{
        PrintTree(root, -1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
        AddList(root, StrToInt(Edit1->Text));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button6Click(TObject *Sender)
{
        Find(root, StrToInt(Edit1->Text));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
        Delete(root, StrToInt(Edit1->Text));
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button4Click(TObject *Sender)
{
        count = 0;
        Calc(root);
        Memo1->Lines->Add("���������� ������� = " + IntToStr(count));        
}
//---------------------------------------------------------------------------

